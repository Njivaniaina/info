#include <stdio.h>

int main () {
	printf("Cette programme a pour but de faire deviner un nombre a l'ordinateur.\n");
	
	int max=100,
		min=0,
		n=110, 
		i=50;
	int reponse=0;
	int coups=0;
	
	while(n != 1){	
		printf("Est-ce que le nombre est superieur ou egal a %d ?\n[(1)Oui et (2)Non] :", i);
		scanf("%d", &reponse);
		if(reponse == 1){
			min=i;
			i=min+((max-min)/2);
		}
		else if(reponse == 2){
			max=i;
			i=max-((max-min)/2);
		}
		coups++;
		n=max-min;
	}
	
	printf("Le nombre est %d !!!\nVous avez fait en %d coups\n", i-1, coups);
		
	return 0;
}
