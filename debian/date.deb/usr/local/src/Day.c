﻿/********************************************************
*	Editeur et createurdu code : Mini(pseudo)	        *
*							   					        *
*	Fonction : Permet de savoir le jour d'un date	    *
*							  							*
*	Date : 04/03/2023				  					*
*							   					  		*
*********************************************************/

#include <stdio.h>
#include "displayAndData.h"    		//Qui contient les prototypes 

int main(){
///Donneees
	int day=0,			//pour le jour
		mouth=13,		//pour le mois
		year=0,			//pour l'an
		rest=0,			//pour le reste 
		codeMouth=0;	//pour le code du mois 
	int restart=1;		//faire un restart
	int key=0;
	
	switch(menu()){			//pour le choix de menu
		case 1:
		while(restart == 1){
			getData(&year, &mouth, &day);		//On lit les donnees 
	
///Analyse
			codeMouth=changeMouth(mouth);		//On reconnait le code du mois choisi
			rest=analyse(day, codeMouth, year);		//On calcul le reste
	
///Sotie
			display(rest, day, mouth, year);		//enfin on affiche just le date
		
			printf("Voulez-vous refaire?(1)Oui ou (2)Non? ");
			while(scanf("%d", &restart) != 1);		//Tant qu'un chiffre n'a pas ete taper on atend
		}

		break;
		case 2:
		help();			//ceci est pour l'aide
		break;
	}
	
	printf("\nTaper un nombre pour continuer.");
	scanf("%d", &key);
	
	return 0;
}
