﻿#include <stdio.h>

int menu(){           ///affichage du menu de la programe
	int choix=0;
	printf("]=[====>  BIENVENUE DANS CETTE PROGRAMME  <====]=[\n\n");
	printf("\t1-Demarer\n");
	printf("\t2-Aide\n");
	while(choix < 1 || choix >2){     	   //Tant qu'il n'a pas choisie entre le menu ,on demande 
		printf("\nVotre choix : ");
	    scanf("%d", &choix);
	}
	return choix;
}

void display(int rest, int day, int mouth, int year){
	char mouthLong[12][10]={"Janvier","Fevrier","Mars","Avril","Mai","Juin","Juillet","Aout","Septembre","Octobre","Novembre","Decembre"};				//Pour stoquer les mois dans un tableau de 2 dimesion
	if(year%4 == 0 && (mouth == 1 || mouth == 2)){		//si l'annees est bicextile, il y a une decalage de temps dans le reste
		switch(rest){
			case 1:			//en celui ci 1 represente le Dimanche et etc... pour les jours suivant
			     printf("Le jour est : Dimanche %d %s %d\n\n", day, mouthLong[mouth-1], year);
			break;
			case 2:
			printf("Le jour est : Lundi %d %s %d\n\n", day, mouthLong[mouth-1], year);
			break;
			case 3:
			printf("Le jour est : Mardi %d %s %d\n\n", day, mouthLong[mouth-1], year);
			break;
			case 4:
			printf("Le jour est : Mercredi %d %s %d\n\n", day, mouthLong[mouth-1], year);
			break;
			case 5:
			printf("Le jour est : Jeudi %d %s %d\n\n", day, mouthLong[mouth-1], year);
			break;
			case 6:
			printf("Le jour est : Vendredi %d %s %d\n\n", day, mouthLong[mouth-1], year);
			break;
			case 0:
			printf("Le jour est : Samedi %d %s %d\n\n", day, mouthLong[mouth-1], year);
			break;
		}	
	}
	else{				//Mais si l'an est normal alors :
		switch(rest){	//0 represent le Dimanche et etc...
			case 0:
			     printf("Le jour est : Dimanche %d %s %d\n\n", day, mouthLong[mouth-1], year);
			break;
			case 1:
			printf("Le jour est : Lundi %d %s %d\n\n", day, mouthLong[mouth-1], year);
			break;
			case 2:
			printf("Le jour est : Mardi %d %s %d\n\n", day, mouthLong[mouth-1], year);
			break;
			case 3:
			printf("Le jour est : Mercredi %d %s %d\n\n", day, mouthLong[mouth-1], year);
			break;
			case 4:
			printf("Le jour est : Jeudi %d %s %d\n\n", day, mouthLong[mouth-1], year);
			break;
			case 5:
			printf("Le jour est : Vendredi %d %s %d\n\n", day, mouthLong[mouth-1], year);
			break;
			case 6:
			printf("Le jour est : Samedi %d %s %d\n\n", day, mouthLong[mouth-1], year);
			break;
		}	
	}
}

void getData(int* a, int* b, int* c){		//entrer les donnees utils
	printf("Enter l'an: ");
	while(scanf("%d", a) != 1){				//Tant qu'une chiffre n'a pas ete taper ,on retape
		printf("Attention!!!Vous n'avez pas taper un chiffre.\nRetaper l'an: ");
	}
	printf("Enter le mois: ");
	while(scanf("%d", b) != 1 || 12 < (*b)){		//	Tant que le mois n'a pas ete taper correctement ,on previent
		printf("Attention!!!Veiller a mettre en chiffre ou vous avez taper plus de 12.\nRetaper le mois: ");
	}
	printf("Enter le jour: ");
	if((*b)==1||(*b)==3||(*b)==5||(*b)==7||(*b)==8||(*b)==10||(*b)==12){		//	tant que le date n'a pas ete taper corectement dans les mois qui a 31 jour , on retape
		while(scanf("%d", c) != 1 ||( (*c)>31||(*c)==0)){		
			printf("Attention!!!Vous n'avez pas taper un chiffre ou cette date n'existe pas.\nRetaper le jour: ");
		}
	}
	if(*(b)==4||(*b)==6||(*b)==9||(*b)==11){
		while(scanf("%d", c) != 1 ||( (*c)>30||(*c)==0)){			//	tant que le date n'a pas ete taper corectement dans les mois qui a 30 jour , on retape	
			printf("Attention!!!Vous n'avez pas taper un chiffre ou cette date n'existe pas.\nRetaper le jour: ");
		}
	}
	if((*b)==2&&(*a)%4!=0){
		while(scanf("%d", c) != 1 ||( (*c)>28||(*c)==0)){		//dans le mois du fevrier , si l'an n'est pas bicextile, alors les jours sont 28
			printf("Attention!!!Vous n'avez pas taper un chiffre ou cette date n'existe pas.\nRetaper le jour: ");
		}
	}
	if((*b)==2&&(*a)%4==0){			//sinon 29 jours
		while(scanf("%d", c) != 1 ||((*c)>29||(*c)==0)){
			printf("Attention!!!Vous n'avez pas taper un chiffre ou cette date n'existe pas.\nRetaper le jour: ");
		}
	}
}

int changeMouth(int m){			//Cette foction pemet de modifier le codage des mois pour la calcul de jour car il y a un code pour le moi
	int code=0;
	switch(m){
		case 1:
			code=0;
		break;
		case 2:
			code=3;
		break;
		case 3:
			code=3;
		break;
		case 4:
			code=6;
		break;
		case 5:
			code=1;
		break;
		case 6:
			code=4;
		break;
		case 7:
			code=6;
		break;
		case 8:
			code=2;
		break;
		case 9:
			code=5;
		break;
		case 10:
			code=0;
		break;
		case 11:
			code=3;
		break;
		case 12:
			code=5;
		break;
	}
	return code;
}

int analyse( int day, int code, int year){ 		//on obtient par cette foction la nombre d la reste de division qui permet d'identifier le jour
	int r=0;
	int frac=0,
		sum=0,
		y=0;
	
	if(year >= 1900){			//On soustrait l'an par 1900
		y=year-1900;
	}
	else{
		y=1900-year;
	}
	frac=y/4;		//on le divise par 4 pour l'anne biscecstile
	
	sum=y+frac+code+day;	//On addition tous les resultat mais le mois est le code qu'on a vue
	r=sum%7;				//On a le reste
	
	return r;
}

void help(){			//Ceci est juste une aide pour compredre le programe
	printf("\n\t====> AIDE <====");
	printf("\nCette programme permet de savoir le jour exacte d'un date");
	printf("\nCette programme a ete realizer par mini,  pseudo de <Njiva>");
}
