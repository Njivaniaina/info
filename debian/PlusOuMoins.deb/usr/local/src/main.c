﻿/********************************************************
 * 														*
 * 	Code by Mini										*
 * 														*
 * 	Type : jeux de nombre 								*	
 * 														*	
 * 	Date : 07/03/2023									*
 * 														*
 ********************************************************/

#include <stdio.h>
#include "tool.h"    		//Qui contient les protypes utiles dans cette programme

int main(){
	
	variable var;			//Structure des variables utiles 
	int refaire=1, exit=0, v=0;			//var. restart et pour quitter et pour l'aide
	
///Données
	while(!exit){
		switch(menu()){
			case 1:
			while(refaire==1){
			
				var.max=100;				//Contient le maximum des nombres choisis
				var.min=1;					//Contient le minimum des nombres choisis
				var.nombreR=bols(var.max,var.min);		//Le nombre aleatoire choisis par l'ordinateur
				var.nombre=0;				//nombre taper par le joueur
				var.coups=10;				//nombre de coups qu'un joueur a
				while(var.coups != 0 && var.nombre != var.nombreR){			///Tant que le nombre de coups n'est pas 0 ou le nombre n'est pas trouver , on fait :
					subTitle(var.coups);			//Dire le nombre de coups et de taper un nombre 
					getnum(&var.nombre);			//lire le nombre taper 
		
///Traitement de donnees
					analyse(var.nombreR, var.nombre, &var.coups);		//analyser le nombre taper si plus ou moins ou égale
///Sortie
				}
				display(var.coups, var.nombreR, var.nombre);        //dire si le joueur à gagner ou pas
				printf("\n\n\t1-Restart\n\t2-Retour\n\nVotre choix : ");    //demander le restart
				scanf("%d", &refaire);
				system("clear");			//Effacer le terminal
			} 
			break;
			
			case 2:
			help();				//Afficher un menu d'aide
			system("clear"); 
			printf("\n\t1-Retour\n\nVotre choix :");
			scanf("%d", &v);
			break;
			
			default:
			exit=1;
			break;
		}
		system("clear"); 
	}
	return 0;
}
