﻿#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct variable variable;
struct variable {
	int nombreR;
	int nombre;
	int coups;
	int max;
	int min;
};

int bols(int max, int min){
	int num=0;
	srand(time(NULL));
	num = ( rand() % (max-min+1) )-min;
	return num;
}

void getnum(int* number){
	while(scanf("%d", number) != 1){
		printf("Veuillez bien a ce que vous taper.\n");
	}
}

void analyse(int n, int num, int* c){
	if(n<num){
		printf("C'est moins!\n\n");
		(*c)--;
	}
	else if(n>num){
		printf("C'est plus!\n\n");
		(*c)--;
	}
}

void display(int coups, int n, int m){
	if( n == m ){
		printf("\nBien jouer!!!\nLe nombre est : %d", n);
	}
	else if(n!=m){
		printf("\nOh!!! Vous avez perdu!!!\nLe nombre est : %d", n);
	}
}

void subTitle(int c){
	printf("Vous avez %d coups.\n", c);
	printf("Taper un nombre: ");
}

int menu(){
	int choise=0;
	
	printf("\t\t----------------------------\n");
	printf("\t\t|=====>  BIENVENUE   <=====|\n");
	printf("\t\t----------------------------\n\n");
	printf("\t1-Jouer\n");
	printf("\t2-Aide\n");
	printf("\t3-Quite\n");
	while(choise < 1 || choise > 3){
		printf("\nVotre choix : ");
	    scanf("%d", &choise);
	}
	
	return choise;
}

void help(){
	printf("Ce jeu consiste a deviner un nombre entre 1 jusqu'a 100 .\nCe jeu a ete realizer par mini,  pseudo de <Njiva>");
}
